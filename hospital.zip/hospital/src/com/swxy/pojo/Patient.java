package com.swxy.pojo;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author ZuoLi
 * @description
 * @date 2022/12/3
 */
public class Patient implements Serializable {

    private int id;
    private String name;
    private String sex;
    private int age;
    private String phone;
    private String depaertment;
    private String type;
    private double price;
    private  int state;
    private String register_time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDepaertment() {
        return depaertment;
    }

    public void setDepaertment(String depaertment) {
        this.depaertment = depaertment;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }

    public String getRegister_time() {
        return register_time;
    }

    public void setRegister_time(String register_time) {
        this.register_time = register_time;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", sex='" + sex + '\'' +
                ", age=" + age +
                ", phone='" + phone + '\'' +
                ", depaertment='" + depaertment + '\'' +
                ", type='" + type + '\'' +
                ", price=" + price +
                ", state=" + state +
                ", register_time='" + register_time + '\'' +
                '}';
    }
}
