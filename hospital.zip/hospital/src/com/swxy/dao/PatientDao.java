package com.swxy.dao;

import com.swxy.pojo.Patient;
import com.swxy.util.JdbcUtil;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ZuoLi
 * @description
 * @date 2022/12/3
 */
public class PatientDao {

    public List<Patient> getPatientList() throws SQLException {
        List<Patient> patientList = new ArrayList<>();
        Connection connection = JdbcUtil.getConnection();
        String sql = "select * from tb_patient order by register_time desc";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ResultSet resultSet = preparedStatement.executeQuery();
        while (resultSet.next()) {
            Patient patient = new Patient();
            patient.setId(resultSet.getInt("id"));
            patient.setName(resultSet.getString("name"));
            patient.setSex(resultSet.getString("sex"));
            patient.setAge(resultSet.getInt("age"));
            patient.setPhone(resultSet.getString("phone"));
            patient.setDepaertment(resultSet.getString("department"));
            patient.setType(resultSet.getString("type"));
            patient.setPrice(resultSet.getDouble("price"));
            patient.setState(resultSet.getInt("state"));
            patient.setRegister_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(resultSet.getTimestamp("register_time")));
            patientList.add(patient);
        }
        return patientList;
    }

    public boolean savePatient(Patient patientPatient) throws SQLException {
        Connection connection = JdbcUtil.getConnection();
        String sql = "insert into tb_patient (name,sex,age,phone,department,type,price,state,register_time) values(?,?,?,?,?,?,?,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, patientPatient.getName());
        preparedStatement.setString(2, patientPatient.getSex());
        preparedStatement.setInt(3, patientPatient.getAge());
        preparedStatement.setString(4, patientPatient.getPhone());
        preparedStatement.setString(5, patientPatient.getDepaertment());
        preparedStatement.setString(6, patientPatient.getType());
        preparedStatement.setDouble(7, patientPatient.getPrice());
        preparedStatement.setInt(8, patientPatient.getState());
        preparedStatement.setObject(9, patientPatient.getRegister_time());
        return preparedStatement.executeUpdate() > 0;

    }

    public boolean updatePatient(int id) throws SQLException {
        Connection connection = JdbcUtil.getConnection();
        String sql = "update tb_patient set state=1 where id=?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, id);
        return preparedStatement.executeUpdate() > 0;

    }

    public static void main(String[] args) throws SQLException {
        PatientDao patientDao = new PatientDao();
        List<Patient> patientList = patientDao.getPatientList();
        System.out.println(patientList);
    }
}
