package com.swxy.controller;

import com.swxy.dao.PatientDao;
import com.swxy.pojo.Patient;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.HttpRetryException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author ZuoLi
 * @description
 * @date 2022/12/6
 */
@WebServlet("/add")
public class AddServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String name = req.getParameter("name");
        String sex = req.getParameter("sex");
        String age = req.getParameter("age");
        String phone = req.getParameter("phone");
        String department = req.getParameter("department");
        String type = req.getParameter("type");
        Patient patient = new Patient();
        patient.setName(name);
        patient.setSex(sex);
        patient.setAge(Integer.parseInt(age));
        patient.setPhone(phone);
        patient.setType(type);
        patient.setDepaertment(department);
        patient.setState(0);
        patient.setRegister_time(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        if (type.equals("专家医师")) {
            patient.setPrice(25);
        } else if (type.equals("副主任医师")) {
            patient.setPrice(17);
        } else {
            patient.setPrice(8);
        }
        PatientDao dao = new PatientDao();
        try {
            boolean bo = dao.savePatient(patient);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        resp.sendRedirect(req.getContextPath() + "/all");

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }



}