package com.swxy.controller;

import com.swxy.dao.PatientDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @author ZuoLi
 * @description
 * @date 2022/12/3
 */
@WebServlet("/update")
public class UpdateServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PatientDao patientDao = new PatientDao();
        String id = request.getParameter("id");
        try {
            patientDao.updatePatient(Integer.parseInt(id));
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        response.sendRedirect("/all");


    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
